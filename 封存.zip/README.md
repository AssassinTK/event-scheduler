
  # 包場一頁式介面

  This is a code bundle for 包場一頁式介面. The original project is available at https://www.figma.com/design/fJrjC11G9VPiEtm4ChGx4o/%E5%8C%85%E5%A0%B4%E4%B8%80%E9%A0%81%E5%BC%8F%E4%BB%8B%E9%9D%A2.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  